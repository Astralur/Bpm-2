# MusicBee BPM → Plátano en OBS

Un único script de **Python 3.12 de 64 bits** que se carga dentro de OBS Studio en Windows 10. Analiza únicamente una fuente de **Captura de audio de aplicación** configurada para MusicBee, estima el BPM y la fase del pulso, escribe los resultados en los registros de OBS y controla el vídeo de la fuente **Plátano (web)**.

El detector, el reloj de pulsos y el servidor de la página del vídeo se ejecutan dentro del proceso de OBS. No hay una aplicación externa de detección, ni un servidor que tengas que arrancar aparte. Solo guarda audio si pulsas el botón de diagnóstico; no lo envía a Internet. Utiliza CPU; no necesita la RX 6600, Tunebat ni Music Presence.

Versión **1.4.0**: sigue el tempo local en bloques de **2 s**, con una ventana móvil predeterminada de **10 s** y comprobación adicional de los últimos **4 s**. Analiza cinco bandas hasta 11 kHz para reconocer también ataques agudos de baterías con triggers. Normaliza únicamente la copia de análisis; no amplifica el sonido de OBS ni de MusicBee.

## Instalación en tu equipo

1. Comprueba con `winver` que tienes Windows 10 **2004 o posterior**, compilación **19041 o posterior**. OBS utiliza la captura de audio por aplicación a partir de esa versión.
2. Instala **Python 3.12 de 64 bits**. En una terminal de Windows ejecuta:

   ```powershell
   py -3.12 -m pip install numpy==2.2.6 scipy==1.15.3 librosa==0.11.0
   ```

   Son librerías cargadas por el propio script, no otra aplicación de detección. Debes instalarlas en el mismo Python que seleccionas en OBS. Puedes consultar su carpeta con:

   ```powershell
   py -3.12 -c "import sys; print(sys.executable)"
   ```

3. Guarda `musicbee_bpm.py` en una carpeta permanente, por ejemplo `Documentos\OBS Scripts`. No necesita estar dentro de `Program Files`.
4. En **OBS → Herramientas → Scripts → Configuración de Python**, selecciona la carpeta de ese Python 3.12. Reinicia OBS si acabas de cambiarla. Carga `musicbee_bpm.py` con el botón **+** de la pestaña Scripts.

## Aislar MusicBee

1. Abre MusicBee y reproduce una canción.
2. En la escena activa de OBS añade una **Captura de audio de aplicación** y llámala **MusicBee**. También puedes reutilizar una fuente existente de ese tipo.
3. Selecciona la ventana de **MusicBee.exe**. En la prioridad de coincidencia, elige la opción que busca una ventana del **mismo ejecutable**. Esto permite que siga capturando cuando cambia el título de la canción.
4. En el script, escribe el nombre exacto de esa fuente y activa **Activar detección de MusicBee**.

El script rechaza Audio de escritorio, otras aplicaciones y capturas con coincidencia por título o clase. No sustituye silenciosamente el audio aislado por la mezcla del dispositivo. Mantén la fuente en una escena activa. Si cambias la configuración de audio de OBS o sustituyes esa fuente, desactiva y reactiva el detector.

No actives ASIO ni la salida WASAPI exclusiva en MusicBee para este uso: pueden eludir la captura compartida de Windows. Si el medidor de la propia fuente de OBS no se mueve, hay que resolver primero su captura. Si ya emites Audio de escritorio, evita enviar dos veces la música al directo mediante la configuración de pistas o el mute de la fuente. El análisis recibe el audio de la fuente antes de su fader/mute.

## Conectar el vídeo

1. Reutiliza o crea una fuente de tipo **Navegador** llamada exactamente **Plátano (web)**. Una **Fuente multimedia** no sirve para este control.
2. En el selector del script elige tu archivo:

   ```text
   C:\Program Files\obs-studio\data\obs-plugins\frontend-tools\scripts\Banana\Comp 1.mp4
   ```

3. Pulsa **Conectar Plátano (web) al vídeo seleccionado**. El botón configura la fuente para la página local del script a 1080 × 1080 y 60 fps. Conserva sus filtros. No modifica el MP4.
4. Mantén activados **Cambiar la velocidad del plátano con el BPM** y **Alinear cada bote con el pulso musical**.
5. Tu MP4 tiene fondo verde: conserva o añade un filtro **Clave de color / Chroma Key** en la fuente para quitarlo.

La página se sirve exclusivamente en la interfaz de bucle local. No necesita OBS WebSocket, depuración remota del navegador, una web externa ni permisos de administrador. El servidor se inicia con el script y se detiene al descargarlo. Si el puerto 17865 está ocupado, elige otro y vuelve a pulsar Conectar. Tras reiniciar OBS, el script guardado vuelve a iniciar el servidor en ese puerto; si el navegador se quedó en una página de error, refresca la fuente.

### Si el plátano no responde

Pulsa **Probar plátano: 90 → 150 BPM (8 segundos)**. La prueba vuelve a conectar la fuente al vídeo y utiliza cuatro segundos a 90 BPM y cuatro a 150 BPM, independientemente de la detección. Los registros la identifican como **PRUEBA MANUAL**, nunca como BPM detectado. Después vuelve al detector.

- Si cambia de ritmo durante la prueba, la conexión con la animación funciona. Cuando `bpm` es `null`, la reproducción normal a `rate: 1.0` es deliberada porque aún no hay un pulso fiable.
- Si no cambia, comprueba el nombre y tipo Navegador de la fuente, la ruta del MP4 y los errores del servidor en el registro.
- Si al pausar MusicBee aparece «Silencio», la señal capturada sigue su reproducción; eso no garantiza que el algoritmo reconozca el pulso de esa canción.

Para actualizar, desactiva y quita el script de la lista de OBS, reemplaza `musicbee_bpm.py` y vuelve a añadirlo. Comprueba que el registro indique **Versión 1.4.0**. Las dependencias son las mismas que en 1.3.0. Si OBS conserva tus ajustes anteriores, establece la ventana en **10 s** y el rango en **40–320 BPM** para empezar; puedes acotarlo después según la música. El máximo configurable es 360 BPM.

## Alinear cada bote

Con solo control de velocidad, `velocidad = BPM / 120`: 90 BPM → 0,75×, 120 → 1×, 150 → 1,25×.

Con la alineación activada, el script también estima **cuándo cae cada pulso**. La página sigue la posición de cada pulso previsto mediante velocidad y pequeñas correcciones continuas. Solo realiza un salto de posición si hay una desviación importante, con un límite de frecuencia para evitar bloquear el decodificador. No espera una consulta web para decidir cada bote: extrapola el reloj de pulsos usando el reloj del navegador.

En el MP4 que has enviado hay cuatro posiciones de impacto, calibradas aproximadamente en los fotogramas 30, 57, 85 y 118 de sus 120 fotogramas:

```text
0.5, 0.95, 1.416667, 1.966667
```

Se conservan las cuatro poses originales. Como los impactos no están separados exactamente 0,5 s en el vídeo, cada tramo se ajusta ligeramente para que el siguiente impacto coincida con el siguiente pulso. La velocidad media conserva la base de 120 BPM. Si cambias de vídeo, ajusta **Instantes de impacto**; deben ser segundos ordenados y menores que su duración.

**Desfase visual en ms** compensa la latencia de tu salida de audio y la representación de OBS:

- Si el plátano cae antes del golpe que escuchas, aumenta el valor positivo.
- Si cae después, usa un valor negativo.
- Prueba con una canción de percusión marcada y ajusta en pasos de 5–20 ms. Usa el audio con el que realmente emites o monitorizas para calibrarlo.

La ventana móvil predeterminada es de 10 s, ajustable entre 8 y 24 s. El seguimiento empieza con 4 s de audio y exige dos lecturas compatibles: la primera sincronización puede llegar aproximadamente a los **5 s** después de preparar el motor si ya hay suficientes pulsos. Los tempos lentos y los pasajes poco claros necesitan más contexto. El BPM se revisa cada 1 s y la fase cada 250 ms. Los cambios pequeños actualizan la velocidad continuamente; los saltos se verifican antes de adoptar el nuevo tempo. Mientras llega audio, una lectura débil conserva el último BPM fiable hasta ocho segundos; el registro lo indica como `bpm_held: true`. El silencio sostenido o la pérdida de captura restablecen el estado cuando se detectan, sin esperar esos ocho segundos, y vuelven a velocidad normal.

Se sigue el **pulso musical estimado**, no cada instrumento, subdivisión o transitorio. El ritmo libre, las introducciones sin percusión, la síncopa y la ambigüedad entre mitad/doble tempo pueden provocar errores. Usa los límites de BPM y la corrección **×0,5 / ×1 / ×2** cuando sea necesario. La sincronización no promete precisión de muestra de audio: intervienen la captura, el análisis, los fotogramas del MP4 y la latencia de OBS.

## Registros y diagnóstico

Abre **Herramientas → Scripts → Registro de scripts** o el registro de OBS y busca `[MusicBee BPM]`.

Los registros incluyen versiones de Python/OBS, fuente seleccionada, frecuencia y canales de audio, BPM bruto y estabilizado, multiplicador, nivel RMS, confianza de periodicidad, confianza de fase, tiempo de análisis, bloques perdidos, estado y pulsos previstos. `confidence` y `phase_confidence` son indicadores del algoritmo, no probabilidades de acierto. Los pulsos se etiquetan como **previstos** porque el reloj interpola entre observaciones de audio.

Los diagnósticos incluyen `analysis_band` (banda elegida), `band_candidates` (candidatos de las cinco bandas del contexto reciente), `segments` (inicio, final, BPM, confianza y banda de cada bloque de 2 s), `local_context_seconds` (contexto utilizado para el BPM actual), `verification_context_seconds` y `tempo_change_confirmed` (confirmación de una sección distinta). Los tiempos de los bloques son relativos a la ventana móvil, no al inicio de la canción. Un bloque con pocos golpes puede mostrar `bpm: null` aunque el contexto más largo permita seguir el tempo.

También incluye `input_peak_dbfs` (pico real), `crest_db`, `level_variation_db` y `low_input_level`. Un nivel bajo por sí solo no demuestra que sea la causa del fallo; estos datos ayudan a distinguir música baja, audio casi constante y falta de periodicidad.

La señal de audio no proporciona el título ni el artista; este script no inventa esos metadatos ni depende de Music Presence para obtenerlos.

- **No module named numpy/scipy:** instala las dependencias con el mismo Python 3.12 que usa OBS.
- **No existe la fuente / tipo no admitido:** comprueba el nombre exacto y el tipo Captura de audio de aplicación.
- **Prioridad de coincidencia:** selecciona la opción por ejecutable en esa captura.
- **Sin audio:** comprueba el medidor de la captura, la escena activa y el modo de salida de MusicBee.
- **BPM a mitad o al doble:** ajusta el multiplicador o acota el rango. El multiplicador también afecta al reloj de botes.
- **Página vacía:** revisa que el MP4 existe, que el script está cargado y que el puerto está libre. Refresca la fuente después de corregirlo.

## Validación y desarrollo

Las pruebas de desarrollo comprueban tempo y fase, deriva gradual de 100 a 102 BPM, cambios de sección incluyendo mitad/doble tempo, ataques agudos con guitarra distorsionada y vibrato, acentos, pequeñas variaciones humanas de tiempo y subdivisiones de doble pedal. También verifican rechazo de silencio/tono/ruido, aislamiento de la selección de fuente, copia segura del callback, procesamiento continuo, peticiones HTTP parciales del vídeo y reproducción/sincronización en Chromium con el MP4 real. Las señales musicales de estas pruebas son sintéticas; no demuestran precisión universal para todos los géneros.

```bash
python3.12 -m venv .venv
.venv/bin/python -m pip install -r requirements-dev.txt
.venv/bin/python -m pytest -q
BPM_TEST_VIDEO="/ruta/Comp 1.mp4" CHROMIUM_PATH=/usr/bin/chromium .venv/bin/python -m pytest -q
```

Sin `BPM_TEST_VIDEO`, la prueba de navegador se omite explícitamente. Chromium y Playwright son herramientas de desarrollo: **no se instalan para usar el script en OBS**.

Las pruebas automatizadas se han ejecutado en Linux con Python 3.12, incluido el vídeo real en Chromium. La captura real de MusicBee, la carga de `obs.dll` y el ajuste de latencia en Windows quedan pendientes de comprobar en tu equipo; las pruebas simuladas del callback no sustituyen esa comprobación.

En señales sintéticas, el tempo estabilizado sigue la deriva de 100 a 102 BPM con menos de 0,5 BPM de error al final de la rampa de 10 s. Los cambios de sección de 120 a 240 y de 180 a 90 BPM se reflejan en 4 s; de 120 a 180 BPM, en 3 s. Son medidas de estas señales, no una garantía de latencia o precisión para cualquier grabación. También se comprueba una señal rítmica con RMS de −49,3 dBFS, el nivel observado en los registros anteriores.

El acceso al audio usa la API pública de libobs `obs_source_add_audio_capture_callback` mediante `ctypes`, porque el enlace Python no adapta ese callback. Mantiene las referencias a la fuente y al callback hasta desconectarlos al desactivar/descargar el script. Referencias de compatibilidad: [captura por aplicación de OBS](https://github.com/obsproject/obs-studio/blob/master/plugins/win-wasapi/plugin-main.cpp), [API de audio](https://github.com/obsproject/obs-studio/blob/master/libobs/obs.h) y [estructura del callback](https://github.com/obsproject/obs-studio/blob/master/libobs/media-io/audio-io.h).

## Recuperación de reproducción en 1.2.0

Al activar el detector se conecta automáticamente la fuente Navegador al servidor local con la versión actual en su URL. La página vuelve a reproducir el MP4 si queda pausado o finalizado; vigila el avance de fotogramas y recarga el vídeo si se bloquea. Una excepción de JavaScript o una petición fallida no elimina el bucle de animación. Cuando no hay BPM válido, el vídeo continúa a velocidad normal.

Los registros `Navegador:` indican `playing`, `playback_rate`, `bpm`, el avance del vídeo y las recuperaciones efectuadas. Esos datos comprueban la respuesta del navegador y permiten distinguirla de los pulsos calculados por el detector. Mantén el script cargado y la fuente en una escena visible. Evita tener dos versiones del script o scripts antiguos de BPM controlando la misma fuente. El registro recibido también contiene advertencias de `soundcard`, que este script no utiliza.

## Seguimiento local en 1.4.0

Cada segundo, el detector vuelve a analizar la ventana móvil y la divide en bloques de 2 s. Calcula ataques espectrales SuperFlux por separado en graves (30–250 Hz), medios bajos (250–1500 Hz), medios altos (1500–4000 Hz), agudos (4000–11000 Hz) y el espectro completo. El BPM es una frecuencia de pulsos por minuto: la frecuencia en Hz donde se escucha el bombo sirve para localizar sus ataques, no determina el tempo.

Combina periodicidad, ajuste de fase y acuerdo entre bandas ponderado por la energía de sus ataques. Esto reduce los falsos pulsos debidos al vibrato de una banda casi constante. Excluye picos recortados en los bordes de los bloques e interpola sus tiempos entre fotogramas de análisis para distinguir cambios pequeños de tempo. Prioriza el bloque reciente de 2 s si tiene soporte suficiente; si no, utiliza 4 s o la ventana completa. No obliga a que toda la canción tenga el mismo BPM.

Una variación pequeña actualiza el tempo suavemente. Una sección con cambio fuerte debe obtener lecturas compatibles; si diferentes contextos confirman el salto, puede cambiar también a mitad/doble tempo sin quedar bloqueada por la protección contra alternancias. Si no caben tres pulsos en 2 s, la comprobación utiliza otro contexto de 4 s desplazado. Hay latencia de observación: dos segundos no bastan para medir con precisión cualquier ritmo lento o ambiguo. El algoritmo no garantiza ausencia de errores en todos los géneros.

## Motor musical auxiliar

Cuando ninguno de los contextos por bandas obtiene un pulso válido, se utiliza `librosa` con detección de ataques SuperFlux y seguimiento de pulsos mediante programación dinámica. El resultado se valida por periodicidad y coherencia de fase; los registros lo identifican como `analysis_band: librosa`. Se ejecuta con CPU dentro del script de OBS. La primera carga puede compilar rutinas de Numba durante varias decenas de segundos; el registro anuncia cuándo termina. Después se revisa el audio cada segundo.

La opción **Evitar alternancia entre mitad y doble BPM** mantiene la interpretación elegida cuando el detector alterna entre un tempo y su mitad/doble sin confirmar un cambio de sección. El registro indica `bpm_folded: true` cuando aplica esa corrección. No determina cuál de ambas interpretaciones musicales es la correcta: usa el multiplicador o desactiva la opción si el pulso elegido está a mitad/doble. Los cambios de sección confirmados pueden superar esta protección automáticamente.

### Reproducir un fallo con la señal real

Con la detección activada, pulsa **Guardar 12 s de audio de MusicBee para diagnóstico**. Guarda exclusivamente la fuente capturada en `%LOCALAPPDATA%\MusicBeeBPM\diagnostico-....wav` y muestra la ruta en los registros. No activa el micrófono ni envía el archivo a Internet. La grabación solo se inicia al pulsar ese botón. Si hay una discontinuidad se cancela para evitar una muestra engañosa.

Un registro de BPM no contiene la forma de onda de la canción. Si sigue fallando, ese WAV permite verificar qué audio recibe realmente el script y reproducir el fallo con una señal concreta. La mejora no ha sido validada con la canción del usuario hasta disponer de ese audio.
