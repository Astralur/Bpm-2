# MusicBee BPM → Plátano en OBS

Un único script de **Python 3.12 de 64 bits** que se carga dentro de OBS Studio en Windows 10. Analiza únicamente una fuente de **Captura de audio de aplicación** configurada para MusicBee, estima el BPM y la fase del pulso, escribe los resultados en los registros de OBS y controla el vídeo de la fuente **Plátano (web)**.

El detector, el reloj de pulsos y el servidor de la página del vídeo se ejecutan dentro del proceso de OBS. No hay una aplicación externa de detección, ni un servidor que tengas que arrancar aparte. El audio no se guarda ni se envía a Internet. Utiliza CPU; no necesita la RX 6600, Tunebat ni Music Presence.

## Instalación en tu equipo

1. Comprueba con `winver` que tienes Windows 10 **2004 o posterior**, compilación **19041 o posterior**. OBS utiliza la captura de audio por aplicación a partir de esa versión.
2. Instala **Python 3.12 de 64 bits**. En una terminal de Windows ejecuta:

   ```powershell
   py -3.12 -m pip install numpy==2.2.6 scipy==1.15.3
   ```

   Son librerías cargadas por el propio script, no otra aplicación de detección. Debes instalarlas en el mismo Python que seleccionas en OBS. Puedes consultar su carpeta con:

   ```powershell
   py -3.12 -c "import sys; print(sys.executable)"
   ```

3. Guarda `musicbee_bpm.py` en una carpeta permanente, por ejemplo `Documentos\OBS Scripts`. No necesita estar dentro de `Program Files`.
4. En **OBS → Herramientas → Scripts → Configuración de Python**, selecciona la carpeta de ese Python 3.12. Reinicia OBS si acabas de cambiarla. Carga `musicbee_bpm.py` con el botón **+** de la pestaña Scripts.

## Aislar MusicBee

1. Abre MusicBee y reproduce una canción.
2. En la escena activa de OBS añade una **Captura de audio de aplicación** y llámala **MusicBee**. También puedes reutilizar una fuente existente de ese tipo.
3. Selecciona la ventana de **MusicBee.exe**. En la prioridad de coincidencia, elige la opción que busca una ventana del **mismo ejecutable**. Esto permite que siga capturando cuando cambia el título de la canción.
4. En el script, escribe el nombre exacto de esa fuente y activa **Activar detección de MusicBee**.

El script rechaza Audio de escritorio, otras aplicaciones y capturas con coincidencia por título o clase. No sustituye silenciosamente el audio aislado por la mezcla del dispositivo. Mantén la fuente en una escena activa. Si cambias la configuración de audio de OBS o sustituyes esa fuente, desactiva y reactiva el detector.

No actives ASIO ni la salida WASAPI exclusiva en MusicBee para este uso: pueden eludir la captura compartida de Windows. Si el medidor de la propia fuente de OBS no se mueve, hay que resolver primero su captura. Si ya emites Audio de escritorio, evita enviar dos veces la música al directo mediante la configuración de pistas o el mute de la fuente. El análisis recibe el audio de la fuente antes de su fader/mute.

## Conectar el vídeo

1. Reutiliza o crea una fuente de tipo **Navegador** llamada exactamente **Plátano (web)**. Una **Fuente multimedia** no sirve para este control.
2. En el selector del script elige tu archivo:

   ```text
   C:\Program Files\obs-studio\data\obs-plugins\frontend-tools\scripts\Banana\Comp 1.mp4
   ```

3. Pulsa **Conectar Plátano (web) al vídeo seleccionado**. El botón configura la fuente para la página local del script a 1080 × 1080 y 60 fps. Conserva sus filtros. No modifica el MP4.
4. Mantén activados **Cambiar la velocidad del plátano con el BPM** y **Alinear cada bote con el pulso musical**.
5. Tu MP4 tiene fondo verde: conserva o añade un filtro **Clave de color / Chroma Key** en la fuente para quitarlo.

La página se sirve exclusivamente en la interfaz de bucle local. No necesita OBS WebSocket, depuración remota del navegador, una web externa ni permisos de administrador. El servidor se inicia con el script y se detiene al descargarlo. Si el puerto 17865 está ocupado, elige otro y vuelve a pulsar Conectar. Tras reiniciar OBS, el script guardado vuelve a iniciar el servidor en ese puerto; si el navegador se quedó en una página de error, refresca la fuente.

## Alinear cada bote

Con solo control de velocidad, `velocidad = BPM / 120`: 90 BPM → 0,75×, 120 → 1×, 150 → 1,25×.

Con la alineación activada, el script también estima **cuándo cae cada pulso**. La página corrige la posición de reproducción en cada pulso previsto y pequeñas desviaciones entre pulsos. No espera una consulta web para decidir cada bote: extrapola el reloj de pulsos usando el reloj del navegador.

En el MP4 que has enviado hay cuatro posiciones de impacto, calibradas aproximadamente en los fotogramas 30, 57, 85 y 118 de sus 120 fotogramas:

```text
0.5, 0.95, 1.416667, 1.966667
```

Se conservan las cuatro poses originales. Como los impactos no están separados exactamente 0,5 s en el vídeo, cada tramo se ajusta ligeramente para que el siguiente impacto coincida con el siguiente pulso. La velocidad media conserva la base de 120 BPM. Si cambias de vídeo, ajusta **Instantes de impacto**; deben ser segundos ordenados y menores que su duración.

**Desfase visual en ms** compensa la latencia de tu salida de audio y la representación de OBS:

- Si el plátano cae antes del golpe que escuchas, aumenta el valor positivo.
- Si cae después, usa un valor negativo.
- Prueba con una canción de percusión marcada y ajusta en pasos de 5–20 ms. Usa el audio con el que realmente emites o monitorizas para calibrarlo.

La ventana inicial es de 12 s y se exigen tres lecturas estables: la primera sincronización tarda aproximadamente **16 s**. El BPM se revisa cada 2 s y la fase cada 250 ms. Los cambios de canción necesitan volver a estabilizarse. Con silencio sostenido o pérdida de captura, deja de emitir un pulso válido y vuelve a velocidad normal.

Se sigue el **pulso musical estimado**, no cada instrumento, subdivisión o transitorio. El ritmo libre, las introducciones sin percusión, la síncopa y la ambigüedad entre mitad/doble tempo pueden provocar errores. Usa los límites de BPM y la corrección **×0,5 / ×1 / ×2** cuando sea necesario. La sincronización no promete precisión de muestra de audio: intervienen la captura, el análisis, los fotogramas del MP4 y la latencia de OBS.

## Registros y diagnóstico

Abre **Herramientas → Scripts → Registro de scripts** o el registro de OBS y busca `[MusicBee BPM]`.

Los registros incluyen versiones de Python/OBS, fuente seleccionada, frecuencia y canales de audio, BPM bruto y estabilizado, multiplicador, nivel RMS, confianza de periodicidad, confianza de fase, tiempo de análisis, bloques perdidos, estado y pulsos previstos. `confidence` y `phase_confidence` son indicadores del algoritmo, no probabilidades de acierto. Los pulsos se etiquetan como **previstos** porque el reloj interpola entre observaciones de audio.

La señal de audio no proporciona el título ni el artista; este script no inventa esos metadatos ni depende de Music Presence para obtenerlos.

- **No module named numpy/scipy:** instala las dependencias con el mismo Python 3.12 que usa OBS.
- **No existe la fuente / tipo no admitido:** comprueba el nombre exacto y el tipo Captura de audio de aplicación.
- **Prioridad de coincidencia:** selecciona la opción por ejecutable en esa captura.
- **Sin audio:** comprueba el medidor de la captura, la escena activa y el modo de salida de MusicBee.
- **BPM a mitad o al doble:** ajusta el multiplicador o acota el rango. El multiplicador también afecta al reloj de botes.
- **Página vacía:** revisa que el MP4 existe, que el script está cargado y que el puerto está libre. Refresca la fuente después de corregirlo.

## Validación y desarrollo

El repositorio incluye pruebas de tempo y fase con ritmos sintéticos, rechazo de silencio/tono/ruido, estabilización, aislamiento de la selección de fuente, copia segura del callback, procesamiento continuo, peticiones HTTP parciales del vídeo y reproducción/sincronización en Chromium con el MP4 real.

```bash
python3.12 -m venv .venv
.venv/bin/python -m pip install -r requirements-dev.txt
.venv/bin/python -m pytest -q
BPM_TEST_VIDEO="/ruta/Comp 1.mp4" CHROMIUM_PATH=/usr/bin/chromium .venv/bin/python -m pytest -q
```

Sin `BPM_TEST_VIDEO`, la prueba de navegador se omite explícitamente. Chromium y Playwright son herramientas de desarrollo: **no se instalan para usar el script en OBS**.

Las pruebas automatizadas se han ejecutado en Linux con Python 3.12, incluido el vídeo real en Chromium. La captura real de MusicBee, la carga de `obs.dll` y el ajuste de latencia en Windows quedan pendientes de comprobar en tu equipo; las pruebas simuladas del callback no sustituyen esa comprobación.

El acceso al audio usa la API pública de libobs `obs_source_add_audio_capture_callback` mediante `ctypes`, porque el enlace Python no adapta ese callback. Mantiene las referencias a la fuente y al callback hasta desconectarlos al desactivar/descargar el script. Referencias de compatibilidad: [captura por aplicación de OBS](https://github.com/obsproject/obs-studio/blob/master/plugins/win-wasapi/plugin-main.cpp), [API de audio](https://github.com/obsproject/obs-studio/blob/master/libobs/obs.h) y [estructura del callback](https://github.com/obsproject/obs-studio/blob/master/libobs/media-io/audio-io.h).
