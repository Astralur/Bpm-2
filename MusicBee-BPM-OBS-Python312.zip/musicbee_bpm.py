"""OBS Python script: isolated MusicBee source -> CPU tempo -> video playback.

No audio is saved or uploaded. The analysis classes also run without OBS.
"""
import json
import ctypes
import math
import os
import queue
import re
import sys
import importlib.util
import wave
import threading
import time
from collections import deque
from dataclasses import dataclass, replace
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlsplit

try:
    import obspython as obs
except ImportError:
    obs = None

VERSION = '1.3.0'


@dataclass(frozen=True)
class Estimate:
    bpm: float | None
    confidence: float
    rms_db: float
    reason: str
    beat_offset: float | None = None
    phase_confidence: float = 0.0
    analysis_band: str = 'full'


class TempoAnalyzer:
    """Spectral-flux onset envelope and normalized autocorrelation.

    Confidence is periodicity, not a calibrated probability of a correct BPM.
    """

    def __init__(self, minimum=70, maximum=190):
        import numpy as np
        from scipy import signal
        if importlib.util.find_spec('librosa') is None:
            raise RuntimeError('Instala el motor musical en Python 3.12: py -3.12 -m pip install librosa==0.11.0')
        if not 40 <= minimum < maximum <= 240:
            raise ValueError("El rango debe cumplir 40 <= mínimo < máximo <= 240")
        self.np, self.signal = np, signal
        self.minimum, self.maximum = minimum, maximum
        self.last_envelope = None
        self.selected_band = 'full'
        self.diagnostics = {}
        self.tempo_prior = None

    def onset_envelope(self, samples, sample_rate, band=None):
        np, signal = self.np, self.signal
        # Normalize only the analysis copy. Never change OBS/MusicBee volume.
        samples = np.asarray(samples, dtype=np.float64)
        samples = samples - samples.mean()
        rms = math.sqrt(float(np.mean(samples ** 2)))
        samples = samples * min(100, 0.1 / max(rms, 1e-12))
        divisor = math.gcd(int(sample_rate), 11025)
        audio = signal.resample_poly(samples, 11025 // divisor, int(sample_rate) // divisor)
        _, times, spectrum = signal.stft(audio, fs=11025, nperseg=512,
                                        noverlap=402, boundary=None, padded=False)
        magnitude = np.log1p(100 * np.abs(spectrum))
        magnitude = self.band_magnitude(magnitude, band or self.selected_band)
        flux = np.maximum(np.diff(magnitude, axis=1), 0).sum(axis=0)
        return flux, times[1:], magnitude

    def band_magnitude(self, magnitude, band):
        frequencies = self.np.fft.rfftfreq(512, 1 / 11025)
        limits = {'bass': (30, 250), 'mid': (250, 2000), 'full': (0, 5513)}
        low, high = limits[band]
        return magnitude[(frequencies >= low) & (frequencies < high)]

    def beat_grid(self, flux, times, bpm):
        """Fit a pulse grid to onset peaks; return last beat, quality and tempo."""
        np, signal = self.np, self.signal
        if not len(flux) or float(np.max(flux)) <= 0:
            return None, 0.0, bpm
        peaks, _ = signal.find_peaks(flux, distance=12,
                                    prominence=float(np.max(flux)) * 0.15)
        if len(peaks) < 3:
            return None, 0.0, bpm
        weights = flux[peaks]
        keep = weights > np.max(weights) * 0.20
        peaks, weights = peaks[keep], weights[keep]
        pulse_times = times[peaks]
        period = 60 / bpm
        phases = (pulse_times / period) % 1
        candidates = np.arange(200) / 200
        distances = (phases[:, None] - candidates[None, :] + 0.5) % 1 - 0.5
        scores = (weights[:, None] * np.exp(-0.5 * (distances / 0.08) ** 2)).sum(axis=0)
        phase = candidates[int(np.argmax(scores))]
        error = (phases - phase + 0.5) % 1 - 0.5
        matched = np.abs(error) < 0.16
        confidence = float(weights[matched].sum() / max(float(weights.sum()), 1e-12))
        if matched.sum() < 3 or confidence < 0.35:
            return None, confidence, bpm
        selected = pulse_times[matched]
        indices = np.rint(selected / period - phase)
        fitted_period, origin = np.polyfit(indices, selected, 1, w=np.sqrt(weights[matched]))
        if fitted_period <= 0 or abs(fitted_period / period - 1) > 0.04:
            return None, confidence, bpm
        anchor = float(origin + max(indices) * fitted_period)
        return anchor, confidence, 60 / float(fitted_period)

    def track_phase(self, samples, sample_rate, bpm):
        flux, times, _ = self.onset_envelope(samples, sample_rate)
        return self.beat_grid(flux, times, bpm)

    def music_tracker(self, samples, sample_rate, db):
        """SuperFlux onset features and librosa's dynamic-programming tracker."""
        import librosa
        np = self.np
        audio = np.asarray(samples, dtype=np.float64)
        audio = audio - audio.mean()
        rms = math.sqrt(float(np.mean(audio ** 2)))
        audio *= min(100, .1 / max(rms, 1e-12))
        divisor = math.gcd(int(sample_rate), 11025)
        audio = self.signal.resample_poly(audio, 11025 // divisor, int(sample_rate) // divisor)
        envelope = librosa.onset.onset_strength(y=audio, sr=11025, hop_length=110,
                                               n_fft=512, n_mels=64, max_size=3)
        tempo, beats = librosa.beat.beat_track(onset_envelope=envelope, sr=11025,
                                              hop_length=110, start_bpm=self.tempo_prior or 120,
                                              tightness=80, trim=True, units='time')
        tempo = float(np.asarray(tempo).reshape(-1)[0])
        if len(beats) >= 6:
            fitted_period = float(np.polyfit(np.arange(len(beats)), beats, 1)[0])
            if fitted_period > 0 and abs((60 / fitted_period) / tempo - 1) < .10:
                tempo = 60 / fitted_period
        if not self.minimum <= tempo <= self.maximum or len(beats) < 6:
            return Estimate(None, 0, db, 'seguimiento musical insuficiente', analysis_band='librosa'), envelope, None
        times = np.arange(len(envelope)) * 110 / 11025
        anchor, quality, refined = self.beat_grid(envelope, times, tempo)
        centered = envelope - envelope.mean()
        lag = round(60 * 11025 / (tempo * 110))
        left, right = centered[:-lag], centered[lag:]
        periodicity = float(np.dot(left, right)) / max(math.sqrt(float(np.dot(left, left) * np.dot(right, right))), 1e-12)
        confidence = max(0, min(1, .5 * periodicity + .5 * quality))
        if anchor is None or quality < .60 or periodicity < .15:
            return Estimate(None, confidence, db, 'pulso musical sin soporte suficiente', analysis_band='librosa'), envelope, times
        if self.minimum <= refined <= self.maximum:
            tempo = refined
        return Estimate(round(tempo, 2), confidence, db, 'seguimiento musical', anchor,
                        quality, 'librosa'), envelope, times

    def analyze(self, samples, sample_rate):
        np, signal = self.np, self.signal
        samples = np.asarray(samples, dtype=np.float64)
        if samples.ndim != 1 or not np.all(np.isfinite(samples)):
            raise ValueError("Se necesita audio mono finito")
        rms = float(np.sqrt(np.mean(samples ** 2))) if samples.size else 0.0
        db = 20 * math.log10(max(rms, 1e-12))
        peak = float(np.max(np.abs(samples))) if samples.size else 0.0
        hop = max(1, int(sample_rate / 10))
        length = (len(samples) // hop) * hop
        levels = np.sqrt(np.mean(samples[:length].reshape(-1, hop) ** 2, axis=1)) if length else np.array([rms])
        variation = 20 * math.log10(max(float(np.quantile(levels, .95)), 1e-12) /
                                    max(float(np.quantile(levels, .10)), 1e-12))
        peak_db = 20 * math.log10(max(peak, 1e-12))
        self.diagnostics = {'input_peak_dbfs': round(peak_db, 1),
                            'crest_db': round(peak_db - db, 1),
                            'level_variation_db': round(variation, 1),
                            'low_input_level': db < -40,
                            'band_candidates': {}}
        self.last_envelope = None
        if rms < 0.001:
            return Estimate(None, 0, db, "silencio / nivel demasiado bajo")
        if samples.size < sample_rate * 8:
            return Estimate(None, 0, db, "faltan al menos 8 s de audio")
        _, times, full_magnitude = self.onset_envelope(samples, sample_rate, 'full')
        # STFT leakage from a steady low-frequency sinusoid can itself be
        # periodic. Reject a nearly constant, single-tone signal before looking
        # for beats in any band; retain dynamic bass drums at the same frequency.
        frequency_power = (np.expm1(full_magnitude) ** 2).mean(axis=1)
        tonal_share = float(np.sort(frequency_power)[-3:].sum()) / max(float(frequency_power.sum()), 1e-12)
        if variation < 0.5 and tonal_share > 0.97:
            return Estimate(None, 0, db, 'tono sostenido sin pulsos')
        candidates = []
        total_magnitude = max(float(full_magnitude.sum()), 1e-12)
        for band in ('full', 'bass', 'mid'):
            magnitude = self.band_magnitude(full_magnitude, band)
            flux = np.maximum(np.diff(magnitude, axis=1), 0).sum(axis=0)
            if float(magnitude.sum()) / total_magnitude < 0.02:
                result = Estimate(None, 0, db, 'energía insuficiente en esta banda')
            else:
                result = self.estimate_envelope(flux, times, magnitude, db)
            result = replace(result, analysis_band=band)
            self.diagnostics['band_candidates'][band] = {
                'bpm': result.bpm, 'confidence': round(result.confidence, 3), 'status': result.reason}
            candidates.append((result, flux))
        valid = [pair for pair in candidates if pair[0].bpm is not None]
        def support(pair):
            candidate = pair[0]
            score = candidate.confidence
            if candidate.bpm is not None:
                agreement = sum(other.bpm is not None and abs(other.bpm / candidate.bpm - 1) < .03
                                for other, _ in candidates)
                score += .04 * max(0, agreement - 1)
                if self.tempo_prior is not None and abs(candidate.bpm / self.tempo_prior - 1) < .03:
                    score += .08
            return score
        result, flux = max(valid or candidates, key=support)
        if result.bpm is None or result.confidence < .60:
            tracked, tracked_flux, tracked_times = self.music_tracker(samples, sample_rate, db)
            self.diagnostics['band_candidates']['librosa'] = {
                'bpm': tracked.bpm, 'confidence': round(tracked.confidence, 3), 'status': tracked.reason}
            if tracked.bpm is not None:
                result, flux, times = tracked, tracked_flux, tracked_times
        self.selected_band = result.analysis_band
        self.last_envelope = (flux, times)
        return result

    def estimate_envelope(self, flux, times, magnitude, db):
        np, signal = self.np, self.signal
        original_flux = flux.copy()
        # A steady sinusoid has tiny periodic STFT leakage, not musical beats.
        relative_onset = float(np.quantile(flux, 0.95)) / max(float(magnitude.sum(axis=0).mean()), 1e-12)
        if float(flux.max(initial=0)) < 1e-8 or relative_onset < 0.015:
            return Estimate(None, 0, db, "sin ataques rítmicos")
        flux = np.maximum(flux - np.median(flux), 0)
        flux -= flux.mean()
        if float(np.dot(flux, flux)) < 1e-8:
            return Estimate(None, 0, db, "sin variación rítmica")
        envelope_rate = 11025 / 110
        low = max(1, int(math.floor(60 * envelope_rate / self.maximum)))
        high = int(math.ceil(60 * envelope_rate / self.minimum))
        # Normalize overlapping segments separately to avoid favoring short lags.
        scores = np.zeros(high + 2)
        for lag in range(max(1, low - 1), high + 2):
            left, right = flux[:-lag], flux[lag:]
            denominator = math.sqrt(float(np.dot(left, left) * np.dot(right, right)))
            scores[lag] = float(np.dot(left, right)) / max(denominator, 1e-12)
        peaks, _ = signal.find_peaks(scores)
        peaks = [int(p) for p in peaks if low <= p <= high]
        if not peaks:
            return Estimate(None, 0, db, "sin periodicidad clara en el rango")
        # Prefer the shortest strong repetition: double-length periods can have
        # higher discrete correlation just because their lag lands on a frame.
        best = max(scores[p] for p in peaks)
        lag = min(p for p in peaks if scores[p] >= 0.80 * best) if best > 0 else max(peaks, key=lambda p: scores[p])
        confidence = float(max(0, min(1, scores[lag])))
        a, b, c = scores[lag - 1:lag + 2]
        denominator = a - 2 * b + c
        offset = float(np.clip(0.5 * (a - c) / denominator, -0.5, 0.5)) if denominator else 0
        bpm = 60 * envelope_rate / (lag + offset)
        if not self.minimum <= bpm <= self.maximum or confidence < 0.30:
            return Estimate(None, confidence, db, "periodicidad insuficiente / fuera de rango")
        anchor, phase_confidence, refined = self.beat_grid(original_flux, times, bpm)
        if self.minimum <= refined <= self.maximum:
            bpm = refined
        return Estimate(round(bpm, 2), confidence, db, "estimación", anchor, phase_confidence)


class TempoSmoother:
    def __init__(self, harmonic_guard=True):
        self.harmonic_guard = harmonic_guard
        self.folded = False
        self.recent = deque(maxlen=3)
        self.value = None
        self.missed = 0
        self.held = False

    def reset(self):
        self.recent.clear()
        self.value = None
        self.missed = 0
        self.held = False

    def update(self, estimate):
        self.held = False
        self.folded = False
        self.missed += 1
        if estimate.bpm is None:
            if self.missed > 8:
                self.reset()
                return None
            self.held = self.value is not None
            return self.value
        candidate = estimate.bpm
        if self.harmonic_guard and self.value is not None:
            for factor in (.5, 2):
                if abs(candidate * factor / self.value - 1) < .06:
                    candidate *= factor
                    self.folded = True
                    break
        self.recent.append(candidate)
        if self.value is not None and abs(candidate - self.value) <= max(3, self.value * .025):
            self.value = round(self.value * .65 + candidate * .35, 2)
            self.missed = 0
        elif len(self.recent) >= 2:
            previous, current = list(self.recent)[-2:]
            if abs(previous - current) <= max(3, current * .025):
                self.value = round((previous + current) / 2, 2)
                self.missed = 0
            else:
                self.held = self.value is not None
        if self.missed > 8:
            self.reset()
        return self.value


@dataclass(frozen=True)
class Config:
    enabled: bool = False
    audio_source: str = 'MusicBee'
    source: str = 'Plátano (web)'
    video: str = r'C:\Program Files\obs-studio\data\obs-plugins\frontend-tools\scripts\Banana\Comp 1.mp4'
    minimum: int = 70
    maximum: int = 190
    multiplier: float = 1.0
    control: bool = True
    port: int = 17865
    phase_sync: bool = True
    phase_offset_ms: int = 0
    impact_marks: str = '0.5, 0.95, 1.416667, 1.966667'
    harmonic_guard: bool = True
    analysis_seconds: int = 8


class AudioData(ctypes.Structure):
    # Public libobs ABI: media-io/audio-io.h; MAX_AV_PLANES = 8.
    _fields_ = [('data', ctypes.POINTER(ctypes.c_float) * 8),
                ('frames', ctypes.c_uint32), ('timestamp', ctypes.c_uint64)]


class AudioInfo(ctypes.Structure):
    _fields_ = [('samples_per_sec', ctypes.c_uint32), ('speakers', ctypes.c_int)]


AudioCallback = ctypes.CFUNCTYPE(None, ctypes.c_void_p, ctypes.c_void_p,
                                 ctypes.POINTER(AudioData), ctypes.c_bool)


class SourceAudioTap:
    """Copy source audio via libobs's public callback; never capture the mix.

    ctypes is needed because the OBS Python wrapper does not marshal this
    callback. Hold both callback and source references until removal completes.
    """
    def __init__(self, name):
        import numpy as np
        if os.name != 'nt' or ctypes.sizeof(ctypes.c_void_p) != 8:
            raise RuntimeError('Se requiere OBS para Windows y Python 3.12 de 64 bits')
        if sys.getwindowsversion().build < 19041:
            raise RuntimeError('La captura de aplicación requiere Windows 10 2004 / compilación 19041 o posterior')
        self.np = np
        self.blocks = queue.Queue(maxsize=256)
        self.dropped = 0
        self.callback_error = None
        self.source = None
        self.closed = False
        self.lib = ctypes.CDLL('obs.dll')
        signatures = {
            'obs_get_source_by_name': ([ctypes.c_char_p], ctypes.c_void_p),
            'obs_source_release': ([ctypes.c_void_p], None),
            'obs_get_audio_info': ([ctypes.POINTER(AudioInfo)], ctypes.c_bool),
            'os_gettime_ns': ([], ctypes.c_uint64),
            'obs_source_add_audio_capture_callback':
                ([ctypes.c_void_p, AudioCallback, ctypes.c_void_p], None),
            'obs_source_remove_audio_capture_callback':
                ([ctypes.c_void_p, AudioCallback, ctypes.c_void_p], None),
        }
        for function, (args, result) in signatures.items():
            fn = getattr(self.lib, function)
            fn.argtypes, fn.restype = args, result
        info = AudioInfo()
        if not self.lib.obs_get_audio_info(ctypes.byref(info)):
            raise RuntimeError('OBS no tiene el audio inicializado')
        self.rate = info.samples_per_sec
        self.channels = 2 if info.speakers == 0 else info.speakers
        if self.channels not in (1, 2, 3, 4, 5, 6, 8) or not 8000 <= self.rate <= 192000:
            raise RuntimeError('Formato de audio de OBS no compatible')
        self.source = self.lib.obs_get_source_by_name(name.encode('utf-8'))
        if not self.source:
            raise RuntimeError(f'No existe la fuente de audio «{name}»')
        self.callback = AudioCallback(self._receive)
        self.lib.obs_source_add_audio_capture_callback(self.source, self.callback, None)

    def _receive(self, _param, _source, pointer, _muted):
        # libobs supplies float planar audio after resampling/filters. Muting
        # the source in the stream does not mute analysis of its pre-fader audio.
        if self.closed:
            return
        try:
            data = pointer.contents
            if not 0 < data.frames <= self.rate:
                return
            planes = [self.np.ctypeslib.as_array(data.data[c], shape=(data.frames,))
                      for c in range(self.channels) if data.data[c]]
            if not planes:
                return
            # Avoid anti-phase stereo cancellation.
            mono = max(planes, key=lambda p: float(self.np.dot(p, p))).copy()
            captured_at = time.monotonic() + (data.timestamp - self.lib.os_gettime_ns()) / 1e9
            self.blocks.put_nowait((data.timestamp, captured_at, mono))
        except queue.Full:
            self.dropped += 1
        except Exception as error:
            self.callback_error = f'{type(error).__name__}: {error}'

    def close(self):
        self.closed = True
        if self.source:
            # CDLL releases the GIL while OBS waits for an in-flight callback.
            self.lib.obs_source_remove_audio_capture_callback(self.source, self.callback, None)
            self.lib.obs_source_release(self.source)
            self.source = None


PAGE = '''<!doctype html><html lang="es"><meta charset="utf-8">
<title>Plátano BPM</title><style>
html,body{margin:0;width:100%;height:100%;overflow:hidden;background:transparent}
video{display:block;width:100%;height:100%;object-fit:contain}
</style><video id="banana" src="video" autoplay muted loop playsinline></video>
<script>
const video = document.getElementById('banana');
video.muted = true;
let state = {rate:1}, received = 0, lastBeat = null;
let lastSeek = -1000, lastPlay = -1000, lastReport = 0;
let lastPosition = -1, lastProgress = performance.now(), lastReload = -10000;
let browserError = '', recoveries = 0;
let lastDecoded = performance.now();
const hasFrameCallback = typeof video.requestVideoFrameCallback === 'function';
if (hasFrameCallback) {
  const decoded = () => {lastDecoded = performance.now(); video.requestVideoFrameCallback(decoded);};
  video.requestVideoFrameCallback(decoded);
}
function poseAtBeat(position, duration, markers) {
  const number = Math.floor(position), fraction = position - number;
  const index = ((number % markers.length) + markers.length) % markers.length;
  const start = markers[index];
  const end = index + 1 < markers.length ? markers[index+1] : markers[0] + duration;
  return {time:(start + fraction * (end-start)) % duration, span:end-start, number};
}
function ensurePlaying(now) {
  if ((video.paused || video.ended) && now-lastPlay > 700) {
    lastPlay = now;
    video.play().catch(error => {browserError = String(error);});
  }
}
for (const name of ['canplay','seeked','loadeddata','ended']) {
  video.addEventListener(name, () => ensurePlaying(performance.now()));
}
video.addEventListener('error', () => {
  browserError = 'Error MP4: ' + (video.error ? video.error.code : 'desconocido');
});
function frame(now) {
  // Schedule the next frame before doing anything which might throw.
  requestAnimationFrame(frame);
  try {
    ensurePlaying(now);
    if (Math.abs(video.currentTime-lastPosition) > .002) {
      lastPosition = video.currentTime; lastProgress = now;
    }
    if ((now-lastProgress > 3000 || (hasFrameCallback && now-lastDecoded > 3000)) && now-lastReload > 5000) {
      lastReload = now; lastProgress = now; lastDecoded = now; recoveries++;
      video.load(); ensurePlaying(now);
    }
    const fresh = now-received < 8000;
    const locked = fresh && state.phase_sync && state.bpm > 0 && Number.isFinite(state.beat_age);
    let rate = fresh && Number.isFinite(state.rate) ? state.rate : 1;
    if (locked && Number.isFinite(video.duration) && video.duration > 0) {
      const markers = Array.isArray(state.impact_marks) ? state.impact_marks.filter(x =>
        Number.isFinite(x) && x >= 0 && x < video.duration).sort((a,b) => a-b) : [];
      if (markers.length) {
        const period = 60/state.bpm;
        const age = state.beat_age + (now-received)/1000 - (state.phase_offset_ms || 0)/1000;
        const target = poseAtBeat(age/period, video.duration, markers);
        const error = ((target.time-video.currentTime+video.duration*1.5)%video.duration)-video.duration/2;
        // Avoid repeated seeks: they can leave OBS's decoder constantly seeking.
        const newBeat = lastBeat !== target.number;
        if (!video.seeking && now-lastSeek > 350 &&
            (lastBeat === null || Math.abs(error) > .12 || (newBeat && Math.abs(error) > .065))) {
          video.currentTime = target.time; lastSeek = now;
        }
        lastBeat = target.number;
        rate = target.span/period * Math.max(.85, Math.min(1.15, 1+error*3));
      }
    } else {lastBeat = null;}
    video.playbackRate = Math.max(.1, Math.min(4, rate));
    if (now-lastReport > 2000) {
      lastReport = now;
      fetch('report', {method:'POST', headers:{'Content-Type':'application/json'},
        body:JSON.stringify({playing:!video.paused && !video.ended,
          seeking:video.seeking, ready_state:video.readyState, current_time:video.currentTime,
          playback_rate:video.playbackRate, bpm:state.bpm || null,
          state_age_ms:Math.round(now-received), progress_age_ms:Math.round(now-lastProgress),
          error:browserError, recoveries,
          decoded_frames:video.getVideoPlaybackQuality ? video.getVideoPlaybackQuality().totalVideoFrames : null})}).catch(() => {});
    }
  } catch (error) {browserError = String(error); ensurePlaying(now);}
}
async function update() {
  const started = performance.now();
  const abort = new AbortController();
  const timeout = setTimeout(() => abort.abort(), 1200);
  try {
    const response = await fetch('state', {cache:'no-store', signal:abort.signal});
    if (!response.ok) throw new Error('HTTP ' + response.status);
    const next = await response.json();
    if (!next || typeof next !== 'object') throw new Error('Estado inválido');
    state = next; received = performance.now();
    if (Number.isFinite(state.beat_age)) state.beat_age += Math.min(.25, (received-started)/2000);
  } catch (error) {browserError = String(error);}
  finally {clearTimeout(timeout); setTimeout(update, 100);}
}
requestAnimationFrame(frame); update();
</script></html>
'''


class VideoServer(ThreadingHTTPServer):
    daemon_threads = True
    allow_reuse_address = True

    def __init__(self, port, video):
        self.video = Path(video)
        self.state = {'bpm': None, 'rate': 1.0, 'status': 'esperando audio'}
        self.updated = time.monotonic()
        self.browser_status = None
        self.browser_seen = None
        super().__init__(('127.0.0.1', port), VideoHandler)
        self.thread = threading.Thread(target=self.serve_forever,
                                       kwargs={'poll_interval': 0.2}, daemon=True)
        self.thread.start()

    def publish(self, payload):
        self.state = dict(payload)
        self.updated = time.monotonic()

    def current_state(self):
        if time.monotonic() - self.updated > 6:
            return {'bpm': None, 'rate': 1.0, 'status': 'sin datos recientes'}
        state = dict(self.state)
        anchor = state.pop('beat_anchor', None)
        if anchor is not None:
            state['beat_age'] = time.monotonic() - anchor
        return state

    def close(self):
        self.shutdown()
        self.server_close()
        self.thread.join(timeout=2)


class VideoHandler(BaseHTTPRequestHandler):
    def log_message(self, *_args):
        pass

    def do_HEAD(self):
        self.do_GET(head=True)

    def do_POST(self):
        if urlsplit(self.path).path != '/banana/report' or self.headers.get('Host', '').split(':')[0] not in ('127.0.0.1', 'localhost'):
            self.send_error(404)
            return
        try:
            size = int(self.headers.get('Content-Length', '0'))
            if not 0 < size < 4096:
                raise ValueError('Invalid size')
            report = json.loads(self.rfile.read(size))
            if not isinstance(report, dict):
                raise ValueError('Invalid report')
            allowed = ('playing', 'seeking', 'ready_state', 'current_time', 'playback_rate',
                       'bpm', 'state_age_ms', 'progress_age_ms', 'error', 'recoveries', 'decoded_frames')
            self.server.browser_status = {k: report[k] for k in allowed if k in report}
            self.server.browser_seen = time.monotonic()
            self._body(b'{}', 'application/json', False)
        except (ValueError, TypeError):
            self.send_error(400)
        except (BrokenPipeError, ConnectionResetError):
            pass

    def _body(self, content, mime, head):
        self.send_response(200)
        self.send_header('Content-Type', mime)
        self.send_header('Content-Length', str(len(content)))
        self.send_header('Cache-Control', 'no-store')
        self.end_headers()
        if not head:
            self.wfile.write(content)

    def do_GET(self, head=False):
        # Only fixed routes. No filesystem paths from the request are accepted.
        host = self.headers.get('Host', '').split(':')[0]
        if host not in ('127.0.0.1', 'localhost'):
            self.send_error(403)
            return
        path = urlsplit(self.path).path
        try:
            if path == '/banana/':
                self._body(PAGE.encode(), 'text/html; charset=utf-8', head)
            elif path == '/banana/state':
                self._body(json.dumps(self.server.current_state()).encode(), 'application/json', head)
            elif path == '/banana/video':
                self._video(head)
            else:
                self.send_error(404)
        except (BrokenPipeError, ConnectionResetError):
            pass

    def _video(self, head):
        try:
            handle = self.server.video.open('rb')
        except (FileNotFoundError, PermissionError, IsADirectoryError):
            self.send_error(404, 'Selecciona un MP4 existente en el script')
            return
        with handle:
            size = os.fstat(handle.fileno()).st_size
            start, end = 0, size - 1
            request_range = self.headers.get('Range')
            if request_range:
                match = re.fullmatch(r'bytes=(\d*)-(\d*)', request_range)
                if not match or not any(match.groups()):
                    self.send_error(416)
                    return
                first, last = match.groups()
                if first:
                    start = int(first)
                    end = min(int(last), end) if last else end
                else:
                    start = max(0, size - int(last))
                if start > end or start >= size:
                    self.send_response(416)
                    self.send_header('Content-Range', f'bytes */{size}')
                    self.end_headers()
                    return
            self.send_response(206 if request_range else 200)
            self.send_header('Content-Type', 'video/mp4')
            self.send_header('Content-Length', str(end - start + 1))
            self.send_header('Accept-Ranges', 'bytes')
            if request_range:
                self.send_header('Content-Range', f'bytes {start}-{end}/{size}')
            self.end_headers()
            if not head:
                handle.seek(start)
                remaining = end - start + 1
                while remaining > 0:
                    block = handle.read(min(65536, remaining))
                    if not block:
                        break
                    self.wfile.write(block)
                    remaining -= len(block)


_config = Config()
_worker = None
_tap = None
_server = None
_stop = threading.Event()
_messages = queue.Queue(maxsize=64)
_generation = 0
_beat_log_index = None
_last_source_check = 0.0
_manual_test_started = None
_manual_test_tempo = None
_last_browser_log = 0.0
_record_requested = threading.Event()


def save_audio_diagnostic(_props, _property):
    if not _worker or not _worker.is_alive():
        _log('Activa primero la detección de MusicBee para guardar su audio.', True)
        return False
    _record_requested.set()
    _log('Grabación de diagnóstico solicitada: se guardarán 12 s de la fuente MusicBee en un WAV local.')
    return False


def animation_test_payload(elapsed, config):
    """An explicitly labeled diagnostic clock, never presented as detection."""
    if not 0 <= elapsed < 8:
        return None
    tempo = 90 if elapsed < 4 else 150
    return {'bpm': tempo, 'rate': tempo / 120, 'status': 'PRUEBA MANUAL; no es BPM detectado',
            'phase_sync': config.phase_sync, 'phase_offset_ms': config.phase_offset_ms,
            'impact_marks': impact_marks(config.impact_marks), 'phase_confidence': 0}


def test_animation(props, prop):
    global _manual_test_started, _manual_test_tempo
    if not _server or not Path(_config.video).is_file():
        _log('La prueba necesita un MP4 existente y el servidor local iniciado.', True)
        return False
    prepare_browser(props, prop)
    _manual_test_started = time.monotonic()
    _manual_test_tempo = None
    _log('PRUEBA MANUAL: 4 s a 90 BPM y 4 s a 150 BPM; no utiliza la detección de MusicBee.')
    return False


def impact_marks(text):
    values = [float(value.strip()) for value in text.split(',')]
    if not values or any(not math.isfinite(x) or x < 0 for x in values) or values != sorted(set(values)):
        raise ValueError('Los impactos deben ser segundos crecientes separados por comas')
    return values


def align_anchor(previous, candidate, period):
    """Maintain the pulse count while gently correcting the phase clock."""
    if previous is None:
        return candidate
    error = (candidate - previous + period / 2) % period - period / 2
    return previous + max(-0.03, min(0.03, error * 0.5))


def _enqueue(generation, kind, value):
    try:
        _messages.put_nowait((generation, kind, value))
    except queue.Full:
        pass


def analyze_source(config, generation, stop, tap):
    try:
        import numpy as np
        analyzer = TempoAnalyzer(config.minimum, config.maximum)
        smoother = TempoSmoother(config.harmonic_guard)
        _enqueue(generation, 'log', 'Preparando motor musical librosa. La primera carga puede tardar '
                 'varias decenas de segundos mientras se compilan y guardan sus rutinas.')
        warm_time = np.arange(11025 * 8) / 11025
        warm_audio = np.sin(2 * np.pi * 90 * warm_time) * np.exp(-60 * (warm_time % .5))
        analyzer.music_tracker(warm_audio, 11025, -20)
        _enqueue(generation, 'log', 'Motor musical preparado; comienza el seguimiento del audio de MusicBee.')
        if stop.is_set():
            return
        window_seconds = config.analysis_seconds
        window = deque()
        buffered = since_analysis = 0
        dropped = 0
        previous_end = None
        stable_bpm = anchor = None
        since_phase = 0
        silent_frames = 0
        silence_reported = False
        latest_payload = None
        recording = []
        recorded_frames = 0
        recording_active = False
        last_audio = time.monotonic()
        warned = False
        _enqueue(generation, 'log', f'Fuente aislada: {config.audio_source}; '
                 f'{tap.rate} Hz; {tap.channels} canales; CPU; ventana={window_seconds} s; '
                 f'análisis cada 1 s; rango={config.minimum}–{config.maximum} BPM. '
                 'El título/artista no se obtiene de la señal de audio.')
        while not stop.is_set():
            if tap.callback_error:
                raise RuntimeError(tap.callback_error)
            try:
                timestamp, captured_at, block = tap.blocks.get(timeout=0.25)
            except queue.Empty:
                if time.monotonic() - last_audio > 3 and not warned:
                    _enqueue(generation, 'reset', 'Sin audio: comprueba MusicBee y su fuente activa en OBS')
                    window.clear()
                    buffered = since_analysis = 0
                    previous_end = None
                    stable_bpm = anchor = None
                    smoother.reset()
                    warned = True
                continue
            last_audio, warned = time.monotonic(), False
            gap = previous_end is not None and abs(timestamp - previous_end) > 100_000_000
            previous_end = timestamp + round(len(block) / tap.rate * 1e9)
            if dropped != tap.dropped or gap:
                _enqueue(generation, 'reset', 'Discontinuidad de audio: reiniciando la ventana de análisis')
                dropped = tap.dropped
                window.clear()
                buffered = since_analysis = 0
                smoother.reset()
                stable_bpm = anchor = None
                if recording_active:
                    recording_active = False
                    recording.clear()
                    _enqueue(generation, 'log', 'Grabación cancelada por discontinuidad; vuelve a solicitarla.')
            if _record_requested.is_set():
                _record_requested.clear()
                recording, recorded_frames, recording_active = [], 0, True
            if recording_active:
                recording.append(block.copy())
                recorded_frames += len(block)
                if recorded_frames >= tap.rate * 12:
                    try:
                        folder = Path(os.environ.get('LOCALAPPDATA', str(Path.home()))) / 'MusicBeeBPM'
                        folder.mkdir(parents=True, exist_ok=True)
                        filename = folder / ('diagnostico-' + time.strftime('%Y%m%d-%H%M%S') + '.wav')
                        raw = np.concatenate(recording)[:tap.rate * 12]
                        with wave.open(str(filename), 'wb') as output:
                            output.setnchannels(1)
                            output.setsampwidth(2)
                            output.setframerate(tap.rate)
                            output.writeframes((np.clip(raw, -1, 1) * 32767).astype('<i2').tobytes())
                        _enqueue(generation, 'log', f'Audio de diagnóstico guardado: {filename}. No se ha enviado a Internet.')
                    except OSError as error:
                        _enqueue(generation, 'log', f'No se pudo guardar el diagnóstico: {error}. La detección continúa.')
                    recording.clear()
                    recording_active = False
            silent_frames = silent_frames + len(block) if np.mean(block ** 2) < 1e-6 else 0
            if silent_frames == 0:
                silence_reported = False
            if silent_frames > tap.rate * 2:
                if not silence_reported:
                    _enqueue(generation, 'reset', 'Silencio: reloj de pulsos desactivado')
                    silence_reported = True
                window.clear()
                buffered = since_analysis = since_phase = 0
                smoother.reset()
                stable_bpm = anchor = None
                continue
            window.append(block)
            buffered += len(block)
            since_analysis += len(block)
            since_phase += len(block)
            while window and buffered - len(window[0]) >= tap.rate * window_seconds:
                buffered -= len(window.popleft())
            audio_end = captured_at + len(block) / tap.rate
            if stable_bpm and since_phase >= tap.rate / 4 and buffered >= tap.rate * 4:
                since_phase = 0
                recent = np.concatenate(window)[-tap.rate * 4:]
                if analyzer.selected_band == 'librosa':
                    # Keep the confirmed musical grid between full tracker runs.
                    offset, quality = None, 0
                else:
                    offset, quality, _ = analyzer.track_phase(recent, tap.rate, stable_bpm)
                if offset is not None:
                    anchor = align_anchor(anchor, audio_end - len(recent) / tap.rate + offset, 60 / stable_bpm)
                    payload = dict(latest_payload)
                    payload.update(beat_anchor=anchor, phase_confidence=round(quality, 3))
                    _enqueue(generation, 'phase', payload)
            if buffered < tap.rate * window_seconds or since_analysis < tap.rate:
                continue
            since_analysis = 0
            started = time.monotonic()
            analyzer.tempo_prior = smoother.value
            estimate = analyzer.analyze(np.concatenate(window)[-tap.rate * window_seconds:], tap.rate)
            stable = smoother.update(estimate)
            corrected = round(stable * config.multiplier, 2) if stable else None
            if corrected is not None:
                offset, quality = None, 0.0
                if estimate.bpm is not None and analyzer.last_envelope is not None:
                    offset, quality, _ = analyzer.beat_grid(*analyzer.last_envelope, corrected)
                if stable_bpm and abs(corrected - stable_bpm) > 3:
                    anchor = None
                elif stable_bpm and anchor is not None:
                    anchor = audio_end - (audio_end - anchor) * stable_bpm / corrected
                stable_bpm = corrected
                if offset is not None:
                    anchor = align_anchor(anchor, audio_end - window_seconds + offset, 60 / corrected)
            else:
                stable_bpm = anchor = None
                quality = 0
            latest_payload = {
                'version': VERSION,
                'bpm_raw': estimate.bpm,
                'bpm': corrected,
                'confidence': round(estimate.confidence, 3),
                'rms_dbfs': round(estimate.rms_db, 1),
                'status': 'manteniendo último BPM (lectura débil)' if smoother.held else
                          (estimate.reason if estimate.bpm is None else ('estable' if stable else 'estabilizando')),
                'bpm_held': smoother.held,
                'bpm_folded': smoother.folded,
                'analysis_ms': round((time.monotonic() - started) * 1000, 1),
                'multiplier': config.multiplier,
                'source': config.audio_source,
                'dropped_blocks': dropped,
                'beat_anchor': anchor,
                'phase_confidence': round(quality, 3),
                'analysis_band': estimate.analysis_band,
                **analyzer.diagnostics,
                'phase_sync': config.phase_sync and config.control,
                'phase_offset_ms': config.phase_offset_ms,
                'impact_marks': impact_marks(config.impact_marks),
            }
            _enqueue(generation, 'estimate', latest_payload)
    except Exception as error:
        _enqueue(generation, 'error', f'{type(error).__name__}: {error}. '
                 'Corrige la causa y desactiva/activa la detección para reintentar.')


def _log(message, error=False):
    obs.script_log(obs.LOG_WARNING if error else obs.LOG_INFO, '[MusicBee BPM] ' + message)


def poll():
    global _beat_log_index, _last_source_check, _manual_test_started, _manual_test_tempo, _last_browser_log
    if _tap and time.monotonic() - _last_source_check >= 0.25:
        _last_source_check = time.monotonic()
        try:
            validate_audio_source(_config.audio_source)
        except ValueError as error:
            _log(f'La fuente ha cambiado: {error}. Reactiva la detección después de corregirla.', True)
            _shutdown_capture()
    for _ in range(64):
        try:
            generation, kind, value = _messages.get_nowait()
        except queue.Empty:
            break
        if generation != _generation:
            continue
        if kind not in ('estimate', 'phase'):
            _log(value, kind in ('error', 'reset'))
            if kind in ('error', 'reset') and _server:
                _server.publish({'bpm': None, 'rate': 1.0, 'status': value})
            continue
        value['rate'] = round(value['bpm'] / 120, 5) if value['bpm'] and _config.control else 1.0
        if kind == 'estimate':
            _log(json.dumps(value, ensure_ascii=False))
        if _server:
            _server.publish(value)
    if _server and _manual_test_started is not None:
        payload = animation_test_payload(time.monotonic() - _manual_test_started, _config)
        if payload is None:
            _manual_test_started = None
            _server.publish({'bpm': None, 'rate': 1.0, 'status': 'prueba terminada; esperando detección'})
            _log('PRUEBA MANUAL terminada; vuelve el control por detección de MusicBee.')
        else:
            payload['beat_anchor'] = _manual_test_started + (0 if payload['bpm'] == 90 else 4)
            _server.publish(payload)
            if _manual_test_tempo != payload['bpm']:
                _manual_test_tempo = payload['bpm']
                _log(f"PRUEBA MANUAL: {payload['bpm']} BPM, velocidad media {payload['rate']}×.")
    if _server:
        if time.monotonic() - _last_browser_log > 5:
            _last_browser_log = time.monotonic()
            if _server.browser_seen is not None:
                age = time.monotonic() - _server.browser_seen
                _log('Navegador: ' + json.dumps(_server.browser_status, ensure_ascii=False) +
                     f'; último contacto hace {age:.1f} s', age > 8)
            elif _config.enabled or _manual_test_started is not None:
                _log(f'Sin respuesta del navegador «{_config.source}»: comprueba que la fuente esté visible '
                     'y conectada al vídeo con el botón Conectar.', True)
        state = _server.current_state()
        if _manual_test_started is None and state.get('bpm') and state.get('beat_age') is not None:
            index = math.floor((state['beat_age'] - _config.phase_offset_ms / 1000) * state['bpm'] / 60)
            if index != _beat_log_index:
                _log(f"Pulso previsto #{index}: {state['bpm']:.2f} BPM; fase={state.get('phase_confidence', 0):.2f}; "
                     f"desfase={_config.phase_offset_ms} ms")
                _beat_log_index = index
        else:
            _beat_log_index = None


def _shutdown_capture():
    global _worker, _tap, _generation
    _stop.set()
    _record_requested.clear()
    _generation += 1
    if _tap:
        _tap.close()
        _tap = None
    if _worker is not None:
        _worker.join(timeout=3)
        if _worker.is_alive():
            _log('El análisis aún no ha terminado; no se iniciará otra captura.', True)
            return False
        _worker = None
    if _server:
        _server.publish({'bpm': None, 'rate': 1.0, 'status': 'desactivado'})
    return True


def validate_audio_source(name):
    source = obs.obs_get_source_by_name(name)
    if source is None:
        raise ValueError(f'Crea una fuente «Captura de audio de aplicación» llamada «{name}» para MusicBee')
    try:
        if obs.obs_source_get_unversioned_id(source) != 'wasapi_process_output_capture':
            raise ValueError('Selecciona una Captura de audio de aplicación; no se admite audio de escritorio')
        settings = obs.obs_source_get_settings(source)
        try:
            window = obs.obs_data_get_string(settings, 'window')
            executable = window.rsplit(':', 1)[-1].casefold()
            if executable != 'musicbee.exe':
                raise ValueError('La aplicación seleccionada en esa fuente debe ser MusicBee.exe')
            if obs.obs_data_get_int(settings, 'priority') != 2:
                raise ValueError('En las propiedades de la captura, selecciona la prioridad de coincidencia por ejecutable')
            if obs.obs_data_get_bool(settings, 'exclude_process_tree'):
                raise ValueError('Desactiva la exclusión de proceso: hay que incluir MusicBee')
        finally:
            obs.obs_data_release(settings)
    finally:
        obs.obs_source_release(source)


def prepare_browser(_props, _property):
    if not _server or not Path(_config.video).is_file():
        _log('Selecciona primero el MP4 y comprueba que el servidor local ha arrancado.', True)
        return False
    source = obs.obs_get_source_by_name(_config.source)
    if source is None:
        _log(f'Crea una fuente Navegador llamada «{_config.source}» y vuelve a pulsar el botón.', True)
        return False
    try:
        if obs.obs_source_get_unversioned_id(source) != 'browser_source':
            _log('La fuente de destino debe ser Navegador, no Fuente multimedia.', True)
            return False
        settings = obs.obs_source_get_settings(source)
        try:
            obs.obs_data_set_bool(settings, 'is_local_file', False)
            obs.obs_data_set_string(settings, 'url', f'http://127.0.0.1:{_config.port}/banana/?v={VERSION}')
            obs.obs_data_set_int(settings, 'width', 1080)
            obs.obs_data_set_int(settings, 'height', 1080)
            obs.obs_data_set_bool(settings, 'fps_custom', True)
            obs.obs_data_set_int(settings, 'fps', 60)
            obs.obs_source_update(source, settings)
        finally:
            obs.obs_data_release(settings)
        _log(f'Fuente «{_config.source}» conectada al MP4 local. Base: 120 BPM = 1×. '
             'Conserva los filtros existentes; el MP4 no tiene transparencia.')
    finally:
        obs.obs_source_release(source)
    return False


def script_description():
    return ('Python 3.12 / OBS 64 bits / Windows 10 2004 o posterior. '
            '1. Crea una Captura de audio de aplicación para MusicBee.exe. '
            '2. Selecciona su nombre y activa la detección. '
            '3. Selecciona el MP4, crea la fuente Navegador «Plátano (web)» y pulsa Conectar. '
            'Tras preparar el motor, primera lectura estable: ~9 segundos; registros en Registro de scripts. '
            'Todo se ejecuta dentro de OBS: CPU, captura aislada y página local. '
            'No necesita Music Presence ni la GPU. Sincroniza velocidad y fase de cada bote con el pulso estimado. '
            'Ajusta el desfase para compensar la latencia de tu equipo.')


def script_defaults(settings):
    for name in ('audio_source', 'source', 'video'):
        obs.obs_data_set_default_string(settings, name, getattr(Config(), name))
    obs.obs_data_set_default_int(settings, 'minimum', 70)
    obs.obs_data_set_default_int(settings, 'maximum', 190)
    obs.obs_data_set_default_int(settings, 'port', 17865)
    obs.obs_data_set_default_int(settings, 'analysis_seconds', 8)
    obs.obs_data_set_default_double(settings, 'multiplier', 1.0)
    obs.obs_data_set_default_bool(settings, 'control', True)
    obs.obs_data_set_default_bool(settings, 'phase_sync', True)
    obs.obs_data_set_default_bool(settings, 'harmonic_guard', True)
    obs.obs_data_set_default_string(settings, 'impact_marks', Config().impact_marks)


def script_properties():
    props = obs.obs_properties_create()
    obs.obs_properties_add_bool(props, 'enabled', 'Activar detección de MusicBee')
    obs.obs_properties_add_text(props, 'audio_source', 'Nombre exacto de la Captura de audio de aplicación', obs.OBS_TEXT_DEFAULT)
    obs.obs_properties_add_int(props, 'minimum', 'BPM mínimo', 40, 239, 1)
    obs.obs_properties_add_int(props, 'maximum', 'BPM máximo', 41, 240, 1)
    obs.obs_properties_add_bool(props, 'harmonic_guard', 'Evitar alternancia entre mitad y doble BPM')
    obs.obs_properties_add_int(props, 'analysis_seconds', 'Ventana de audio en segundos', 8, 24, 2)
    multiplier = obs.obs_properties_add_list(props, 'multiplier', 'Corrección de mitad / doble tempo',
                                            obs.OBS_COMBO_TYPE_LIST, obs.OBS_COMBO_FORMAT_FLOAT)
    for label, value in [('Mitad (×0,5)', 0.5), ('Normal (×1)', 1.0), ('Doble (×2)', 2.0)]:
        obs.obs_property_list_add_float(multiplier, label, value)
    obs.obs_properties_add_bool(props, 'control', 'Cambiar la velocidad del plátano con el BPM')
    obs.obs_properties_add_bool(props, 'phase_sync', 'Alinear cada bote con el pulso musical')
    obs.obs_properties_add_int(props, 'phase_offset_ms', 'Desfase visual en ms (+ retrasa el bote)', -1000, 1000, 5)
    obs.obs_properties_add_text(props, 'impact_marks', 'Instantes de impacto dentro del MP4 (segundos)', obs.OBS_TEXT_DEFAULT)
    obs.obs_properties_add_path(props, 'video', 'Vídeo del plátano', obs.OBS_PATH_FILE, 'Vídeo MP4 (*.mp4)', None)
    obs.obs_properties_add_text(props, 'source', 'Nombre exacto de la fuente Navegador', obs.OBS_TEXT_DEFAULT)
    obs.obs_properties_add_int(props, 'port', 'Puerto local (reconecta la fuente si lo cambias)', 1024, 65535, 1)
    obs.obs_properties_add_button(props, 'prepare', 'Conectar Plátano (web) al vídeo seleccionado', prepare_browser)
    obs.obs_properties_add_button(props, 'test_animation', 'Probar plátano: 90 → 150 BPM (8 segundos)', test_animation)
    obs.obs_properties_add_button(props, 'record_diagnostic', 'Guardar 12 s de audio de MusicBee para diagnóstico', save_audio_diagnostic)
    return props


def script_update(settings):
    global _config, _worker, _stop, _tap, _server
    new = Config(
        enabled=obs.obs_data_get_bool(settings, 'enabled'),
        audio_source=obs.obs_data_get_string(settings, 'audio_source').strip(),
        source=obs.obs_data_get_string(settings, 'source'),
        video=obs.obs_data_get_string(settings, 'video'),
        minimum=obs.obs_data_get_int(settings, 'minimum'),
        maximum=obs.obs_data_get_int(settings, 'maximum'),
        multiplier=obs.obs_data_get_double(settings, 'multiplier'),
        control=obs.obs_data_get_bool(settings, 'control'),
        port=obs.obs_data_get_int(settings, 'port'),
        phase_sync=obs.obs_data_get_bool(settings, 'phase_sync'),
        phase_offset_ms=obs.obs_data_get_int(settings, 'phase_offset_ms'),
        impact_marks=obs.obs_data_get_string(settings, 'impact_marks'),
        harmonic_guard=obs.obs_data_get_bool(settings, 'harmonic_guard'),
        analysis_seconds=obs.obs_data_get_int(settings, 'analysis_seconds'),
    )
    if not _shutdown_capture():
        return
    if _server and new.port != _config.port:
        _server.close()
        _server = None
    _config = new
    try:
        if not 1024 <= new.port <= 65535:
            raise ValueError('Puerto local inválido')
        impact_marks(new.impact_marks)
        if not 8 <= new.analysis_seconds <= 24:
            raise ValueError('La ventana de análisis debe estar entre 8 y 24 segundos')
        if _server is None:
            _server = VideoServer(new.port, new.video)
            _log(f'Página del plátano iniciada dentro de OBS; puerto local {new.port}.')
        _server.video = Path(new.video)
        if not new.enabled:
            return
        if not 40 <= new.minimum < new.maximum <= 240 or new.multiplier not in (0.5, 1.0, 2.0):
            raise ValueError('Rango o multiplicador inválido')
        # Fail before registering any native callback when dependencies are missing.
        TempoAnalyzer(new.minimum, new.maximum)
        validate_audio_source(new.audio_source)
        _tap = SourceAudioTap(new.audio_source)
        _stop = threading.Event()
        _worker = threading.Thread(target=analyze_source, args=(new, _generation, _stop, _tap),
                                   name='MusicBee-BPM', daemon=True)
        _worker.start()
        prepare_browser(None, None)
    except Exception as error:
        _log(f'{type(error).__name__}: {error}', True)


def script_load(settings):
    version = obs.obs_get_version_string() if hasattr(obs, 'obs_get_version_string') else 'desconocida'
    _log(f'Versión {VERSION}; Python {sys.version.split()[0]}; OBS {version}; proceso de {ctypes.sizeof(ctypes.c_void_p) * 8} bits. '
         'Captura aislada de MusicBee; análisis CPU; sin consultas externas.')
    obs.timer_add(poll, 20)


def script_unload():
    global _server
    obs.timer_remove(poll)
    _shutdown_capture()
    if _server:
        _server.close()
        _server = None
